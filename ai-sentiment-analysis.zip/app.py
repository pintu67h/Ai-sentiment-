from flask import Flask, request, jsonify, render_template
import joblib
import os

app = Flask(__name__)

# Load model and vectorizer
model = joblib.load("model/sentiment_model.pkl")
vectorizer = joblib.load("model/vectorizer.pkl")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    text = request.form.get("text")
    if not text:
        return jsonify({"error": "No text provided"}), 400

    vec_text = vectorizer.transform([text])
    prediction = model.predict(vec_text)[0]
    return jsonify({"sentiment": prediction})

if __name__ == "__main__":
    app.run(debug=True)
