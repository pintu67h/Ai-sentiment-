# AI Sentiment Analysis

This project is a web application that predicts the sentiment (positive or negative) of user-entered text using a machine learning model.

## Project Structure:
- `app.py`: Flask application script
- `model/train_model.py`: Script to train and save the model
- `templates/index.html`: Frontend interface
- `data/sentiment_data.csv`: Sample dataset
- `requirements.txt`: List of required packages

## Setup Instructions:
1. Clone the repository:
```bash
git clone https://github.com/yourusername/ai-sentiment-analysis.git
cd ai-sentiment-analysis
```
2. Install dependencies:
```bash
pip install -r requirements.txt
```
3. Train the model:
```bash
python model/train_model.py
```
4. Start the Flask server:
```bash
python app.py
```
5. Open your browser and visit `http://127.0.0.1:5000`

---
This project demonstrates basic AI integration with a web interface using Python and is ideal for educational purposes.
